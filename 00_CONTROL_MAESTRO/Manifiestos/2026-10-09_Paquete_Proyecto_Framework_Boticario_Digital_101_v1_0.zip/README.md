# Boticario Digital 101

Modo: INTEGRATE
Framework: 5.1.0

## Problema
En Puerto Rico, quienes consultan plantas medicinales, incluidas personas menores de edad, encuentran información dispersa y sin fuentes trazables. Esa información no distingue entre uso tradicional, evidencia experimental y evidencia clínica. El MVP del Boticario reproduce parte de ese problema: da dosis numéricas sin respaldo clínico, cita fuentes comerciales y atribuye saberes culturales sin documentarlos.

## Propósito
Convertir el Boticario en un nodo de saberes del buen vivir, con fichas estandarizadas y transdisciplinarias que escuchen cada tradición en sus propios términos. Cada afirmación debe tener evidencia trazable, la seguridad debe ajustarse a la audiencia, y cada persona debe tener un portafolio propio que pueda interoperar con las demás apps del ecosistema.

## Continuidad
Plano del Buen Vivir · FICHA-2: auditar la ficha estándar por triangulación de fuentes y proponer la ficha v0.2 como spec de objeto de dominio, para validarla después con el caso del anamú.