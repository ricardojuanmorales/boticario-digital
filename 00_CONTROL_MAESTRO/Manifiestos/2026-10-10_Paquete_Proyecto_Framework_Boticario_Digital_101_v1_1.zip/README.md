# Boticario Digital 101

Modo: INTEGRATE
Framework: 5.1.0

## Problema
En Puerto Rico, quienes consultan plantas medicinales, incluidas personas menores de edad, encuentran información dispersa y sin fuentes trazables. Esa información no distingue entre uso tradicional, evidencia experimental y evidencia clínica. El MVP del Boticario reproduce parte de ese problema: da dosis numéricas sin respaldo clínico, cita fuentes comerciales y atribuye saberes culturales sin documentarlos.

## Propósito
Convertir el Boticario en un nodo de saberes del buen vivir, con fichas estandarizadas y transdisciplinarias que escuchen cada tradición en sus propios términos. Cada afirmación debe tener evidencia trazable, la seguridad debe ajustarse a la audiencia, y cada persona debe tener un portafolio propio que pueda interoperar con las demás apps del ecosistema.

## Continuidad
Decidir: autorizar la activación del anamú (D-A25), los aprendizajes A1–A6 de FICHA-3, declarar la ficha v1.0 o probar un caso alimentario (jengibre), y revisar la excepción D-A16. Después, el JSON Schema de la ficha.